# Windows 批次圖片格式轉換器

一個以 Windows Forms 製作的輕量桌面工具，可一次把多張圖片轉成統一格式。介面使用繁體中文，轉換全程在本機完成。

> 根目錄目前版本：`0.1.0`（早期版本）。已發布的 `v0.1.0` 保持不變。

`versions/` 依使用者需求整理 `v1.0.0` 來源碼候選資料與 `v1.1.0` EXE 候選包。兩者都尚未正式發布；詳見 [版本資料夾索引](versions/README.md) 與 [ROADMAP.md](ROADMAP.md)。

## 功能

- 一次選取多張圖片、匯入整個資料夾（包含子資料夾），或直接拖放圖片。
- 支援 PNG、JPG/JPEG、JFIF、BMP、GIF、TIF/TIFF、ICO 輸入。
- 可輸出 PNG、JPEG、BMP、GIF、TIFF。
- 可調整 JPEG 品質；透明圖片轉成 JPEG 時會以白色填補透明區。
- 逐檔顯示轉換狀態；同名輸出檔自動加上序號，不覆蓋既有檔案。
- 無需第三方套件、安裝程式或網路連線即可使用原始碼版。

## 系統需求

- Windows 10 或更新版本。
- 原始碼版使用 Windows PowerShell 5.1 與 Windows 內建 Windows Forms / GDI+ 元件。
- 目前不支援 macOS、Linux 或瀏覽器執行。

## 使用方式

### 原始碼版

1. 到 [GitHub Releases](https://github.com/1NotAmon/windows-image-format-converter/releases/latest) 下載來源碼 ZIP，解壓縮整個專案資料夾。請勿只下載 `.vbs` 或 `.ps1` 單一檔案。
2. 雙擊 `啟動圖片格式轉換器.vbs`。
3. 加入圖片或資料夾，選擇輸出格式與輸出位置，再按「開始轉換」。

預設輸出位置為「文件\統一格式\轉換結果」。也可以把圖片拖曳到程式清單。

### v1.1.0 EXE 候選版

`versions/v1.1.0/` 含本機測試過可啟動的 x64 EXE 候選包，但完整轉換矩陣、乾淨 Windows 11 驗收及安全掃描尚未完成，因此不是正式 Release。請先看該資料夾的說明，並自行確認來源和檔案校驗碼。

### 從 PowerShell 啟動

在專案資料夾開啟 Windows PowerShell，執行：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File ".\圖片格式轉換器.ps1"
```

此命令只為該次 PowerShell 程序指定執行原則，不會修改系統或使用者的全域原則。從網路下載任何腳本前，請先確認來源並閱讀程式內容。

## 輸入與輸出格式

| 類型 | 格式 |
| --- | --- |
| 輸入 | PNG、JPG/JPEG、JFIF、BMP、GIF、TIF/TIFF、ICO |
| 輸出 | PNG、JPEG（`.jpg`）、BMP、GIF、TIFF（`.tiff`） |

解碼能力取決於 Windows 內建 GDI+ 對實際圖片內容的支援。副檔名符合但檔案損毀或內容格式不受支援時，該檔會顯示失敗原因。

## 行為與限制

- 轉換不會覆寫既有檔案；若同名檔案已存在，會依序輸出 `_1`、`_2` 等名稱。
- JPEG 品質範圍為 40–100，預設 92；此設定只影響 JPEG 輸出。
- 透明圖片輸出為 JPEG 時，透明區域以白色背景呈現。
- 動畫 GIF 與多頁 TIFF 輸出為靜態圖片，只處理第一個影格／頁面。
- 目前採逐張同步轉換，大量或超大圖片可能需要等待；請勿在轉換途中關閉視窗。
- 程式不會上傳、分析或傳送圖片；所有檔案處理均在本機進行。

## 專案結構

```text
.
├── 圖片格式轉換器.ps1
├── 啟動圖片格式轉換器.vbs
├── build/Build-Exe.ps1
├── tests/
│   ├── SmokeTest.ps1
│   ├── ImportCountTest.ps1
│   └── PackageTest.ps1
├── versions/
│   ├── v1.0.0/              # 來源碼候選快照
│   └── v1.1.0/              # x64 EXE 候選包與第三方聲明
├── .github/workflows/       # GitHub Actions 測試
├── README.md
├── ROADMAP.md
├── LICENSE
├── CHANGELOG.md
├── CONTRIBUTING.md
├── VERSION
└── 使用說明.txt
```

根目錄是唯一的開發主線；`versions/` 是按版本整理的快照與候選成品。該目錄不會覆蓋或取代已發布的 `v0.1.0`。

## 開發與測試

在 Windows PowerShell 5.1 中執行：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File ".\tests\SmokeTest.ps1"
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File ".\tests\ImportCountTest.ps1"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File ".\tests\PackageTest.ps1"
```

`ImportCountTest.ps1` 會建立 21 張 JPG 與 4 張 JFIF，呼叫主程式實際使用的匯入函式，確認 25 張全數列入且重複路徑不增加筆數。`PackageTest.ps1` 會啟動 EXE 視窗並正常關閉；它不取代人工實際轉檔驗收。GitHub Actions 會執行匯入數量與 smoke tests。

### 重建 v1.1.0 EXE

需先在 Windows 安裝固定版本的 PS2EXE：

```powershell
Install-Module -Name ps2exe -RequiredVersion 1.0.18 -Scope CurrentUser
powershell.exe -NoProfile -ExecutionPolicy Bypass -File ".\build\Build-Exe.ps1"
```

建置結果會放在 `versions/v1.1.0/`。PS2EXE 相關聲明和版本資訊列於 `versions/v1.1.0/THIRD-PARTY-NOTICES.txt`。EXE 只是 PowerShell 程式的 Windows 封裝，不是程式碼加密；本專案的 EXE 尚未數位簽署。

## 問題回報

回報問題時，請附上 Windows 版本、輸入副檔名、目標輸出格式，以及清單中顯示的完整錯誤文字。請勿公開上傳含有私人資訊的圖片。

## 授權

本專案原始碼採用 [MIT License](LICENSE)。EXE 候選包另包含 PS2EXE 第三方授權說明；兩者授權範圍請分別閱讀。

# 版本紀錄

本專案的重要變更記錄於此。版本格式採用 `MAJOR.MINOR.PATCH`；候選版在完成驗收前不代表正式 Release。

## 1.4.0

- 新增逐張即時進度、目前處理檔名與成功／失敗／待處理數量；可於目前圖片完成後取消批次。
- 加入轉換完成／取消通知、一鍵開啟輸出資料夾、輸出檔名欄及可複製的完整失敗錯誤明細。
- 記住上次選擇的輸出格式、JPEG 品質及輸出資料夾；設定儲存在目前使用者本機，不記錄匯入圖片清單。
- Windows 10 本機通過 250 張匯入、45 組轉檔／100 張批次／取消、設定記憶、x64 EXE 單視窗、唯一 AppId 隔離安裝／解除安裝及候選 ZIP／校驗碼獨立驗證。
- 對 v1.4.0 候選資料夾執行 Defender 自訂掃描，結果 0 偵測；這不代表 SmartScreen 信譽或程式碼簽章已驗證。
- 乾淨 Windows 10／11、實際 GUI 拖放與 SmartScreen／簽章信任尚未驗收；目前 tag／Release 狀態以 [GitHub Releases](https://github.com/1NotAmon/windows-image-format-converter/releases) 為準。

## 1.3.0 — 正式發布（2026-11-09）

- 更新白底黑字與圓角桌面介面；正規化匯入路徑以改善重複判斷，並確保 JPEG 編碼參數於成功或失敗路徑皆會清理。
- 擴增 250 張 JPG/JFIF 匯入與相對路徑別名回歸，新增同資料夾保護來源圖及 30 次連續 JPEG 轉換資源釋放驗收。
- 9×5 格式轉換矩陣、100 張批次、透明 PNG、JPEG 品質、巢狀資料夾、損毀檔隔離、單一視窗及右鍵安裝／移除往返回歸已通過本機 Windows 10 測試；x64 EXE `1.3.0.0` 的三程序單視窗封裝測試也已通過。
- 新增 Inno Setup 7 繁體中文單檔安裝程式：安裝到目前使用者、不需管理員權限，建立開始功能表捷徑；桌面捷徑可選，右鍵整合預設關閉，勾選會取代本專案舊登錄且解除安裝不還原舊版本。隔離安裝／解除安裝測試通過，測試未啟用右鍵登錄。
- 已建立 GitHub `v1.3.0` 正式 Release；Windows 11 乾淨環境、實際 GUI 拖放及 SmartScreen／簽章信任仍未驗證。Setup 與 EXE 均未簽署；Inno Setup 7.1.1 編譯器的非商業用途限制與商業用戶條件詳見版本 Release Notes／第三方聲明。

## 1.2.0 — 發布說明（2026-11-09）

- 修正檔案總管多選圖片可能分別開啟多個轉換器視窗的問題；多次程式啟動會將圖片路徑合併到單一視窗。
- 提供 Windows x64 EXE、來源碼 ZIP、可攜式 EXE ZIP、右鍵選單安裝／移除工具及 SHA-256 校驗碼。
- 本機 Windows 10 Home 22H2 通過 9 種輸入副檔名 × 5 種輸出格式的 45 組轉檔／重開驗證、100 張批次、透明 PNG、JPEG 白底與品質、巢狀資料夾、去重、同名不覆寫及損毀檔隔離；Defender 自訂掃描無偵測。
- Release Notes 已明確列出尚未完成的實際 GUI 拖放、乾淨 Windows 10／11（含 Windows 11 右鍵）及 SmartScreen／簽章信任驗收。EXE 未簽章；Defender 掃描結果不等同 SmartScreen 或簽章驗證。
- 已發布的 `v0.1.0` 保持不變。
- v1.2.0 文件、測試及發布包已同步至公開 `main`（commit `50e39da`）；GitHub Actions run #37 成功，包含 EXE 單視窗、45 組轉檔／100 張批次及右鍵回歸。正式標籤與下載資產的目前狀態以 [GitHub Releases](https://github.com/1NotAmon/windows-image-format-converter/releases) 頁面為準。

## 1.2.0-rc.1 — 公開候選版（歷史紀錄）

以下狀態記錄於 RC 階段；v1.2.0 最新發布準備與已知限制請見上方記錄及 `versions/v1.2.0/RELEASE-NOTES.md`。

- 修正檔案總管多選圖片可能分別開啟多個轉換器視窗的問題；多次程式啟動會將圖片路徑合併到單一視窗。
- 提供來源碼候選 ZIP、x64 EXE 候選包、SHA-256 校驗碼與 v1.2.0 版本資料夾。
- 右鍵選單安裝器優先尋找 v1.2.0 EXE，並保留 v1.1.0 套件相容回退。
- 本版本仍為公開候選，完整實際轉檔矩陣、100 張批次、乾淨 Windows 10／11 與 Defender／SmartScreen 驗收尚未完成。
- 未建立新的 Git tag 或正式 GitHub Release；已發布的 v0.1.0 保持不變。

以上 RC 驗收狀態是歷史紀錄，不代表後續 v1.2.0 測試結果。

## 0.1.0 — 2026-11-07

- 建立繁體中文 Windows Forms 批次圖片格式轉換器。
- 支援多檔選取、資料夾遞迴匯入及拖放。
- 支援 PNG、JPEG、BMP、GIF、TIFF 輸出與 JPEG 品質調整。
- 加入不覆寫既有檔案的序號命名方式。
- 修正輸入副檔名白名單，加入 JFIF，避免漏掉 `.jfif` 圖片。
- 加入 GitHub 說明、測試及 Windows CI 工作流程。
